from .df_compress import compress


__version__ = "0.1.0"
__author__ = 'Pedro H. Chaves Maia'
__credits__ = 'Institute for Mobility and Social Development'